export default function NotFound() {
  return (
    <div
      className='container-fluid shadow p-2 bg-danger text-white'
      style={{ minHeight: '88vh' }}
    >
      <div className='container text-center'>
        <h4 style={{ marginTop: '200px' }}>There is nothing here! 404</h4>
      </div>
    </div>
  )
}
